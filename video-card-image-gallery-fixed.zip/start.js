#!/usr/bin/env node
/**
 * GPU34 — Start script
 * Запускает Express сервер, который раздаёт и API и собранный фронтенд
 * 
 * Использование:
 *   1. npm run build    (собрать фронтенд)
 *   2. node start.js    (запустить сервер)
 *   
 *   Или для разработки:
 *   1. node server/index.js   (запустить API на :3001)
 *   2. npm run dev             (запустить Vite на :5173)
 */

import './server/index.js';
