const API_BASE = import.meta.env.VITE_API_URL || (import.meta.env.PROD ? '' : 'http://localhost:3001');

function getToken(): string | null {
  return localStorage.getItem('gpu34_token');
}

function authHeaders(): Record<string, string> {
  const token = getToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request(url: string, options: RequestInit = {}) {
  const res = await fetch(`${API_BASE}${url}`, {
    ...options,
    headers: {
      ...authHeaders(),
      ...options.headers,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || 'Request failed');
  }
  return res.json();
}

// Auth
export async function register(username: string, password: string) {
  return request('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
}

export async function login(username: string, password: string) {
  return request('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
}

export async function getMe() {
  return request('/api/auth/me');
}

// Posts
export async function getPosts(params?: {
  tags?: string;
  sort?: string;
  rating?: string;
  search?: string;
}) {
  const query = new URLSearchParams();
  if (params?.tags) query.set('tags', params.tags);
  if (params?.sort) query.set('sort', params.sort);
  if (params?.rating) query.set('rating', params.rating);
  if (params?.search) query.set('search', params.search);
  const qs = query.toString();
  return request(`/api/posts${qs ? '?' + qs : ''}`);
}

export async function getPost(id: string) {
  return request(`/api/posts/${id}`);
}

export async function createPost(formData: FormData) {
  const token = getToken();
  const res = await fetch(`${API_BASE}/api/posts`, {
    method: 'POST',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
    body: formData,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Upload failed' }));
    throw new Error(err.error || 'Upload failed');
  }
  return res.json();
}

export async function updatePost(id: string, data: { tags?: string; rating?: string; source?: string }) {
  return request(`/api/posts/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
}

export async function deletePost(id: string) {
  return request(`/api/posts/${id}`, { method: 'DELETE' });
}

export async function votePost(id: string, direction: 'up' | 'down') {
  return request(`/api/posts/${id}/vote`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ direction }),
  });
}

export async function addComment(postId: string, text: string) {
  return request(`/api/posts/${postId}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text }),
  });
}

export async function deleteComment(postId: string, commentId: string) {
  return request(`/api/posts/${postId}/comments/${commentId}`, { method: 'DELETE' });
}

export async function getTags() {
  return request('/api/tags');
}

export async function getStats() {
  return request('/api/stats');
}

export function getImageUrl(filename: string) {
  return `${API_BASE}/uploads/${filename}`;
}
