import { useState, useEffect, useCallback } from 'react';
import { AuthProvider } from './AuthContext';
import Header from './components/Header';
import TagSidebar from './components/TagSidebar';
import PostGrid from './components/PostGrid';
import PostDetail from './components/PostDetail';
import AdminPanel from './components/AdminPanel';
import { getPosts } from './api';

interface PostSummary {
  id: string;
  filename: string;
  tags: string[];
  rating: string;
  score: number;
  commentCount: number;
  uploader: string;
  createdAt: string;
}

function AppContent() {
  const [page, setPage] = useState('home');
  const [selectedPostId, setSelectedPostId] = useState<string | null>(null);
  const [posts, setPosts] = useState<PostSummary[]>([]);
  const [activeTags, setActiveTags] = useState<string[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [sort, setSort] = useState('date');
  const [ratingFilter, setRatingFilter] = useState('');
  const [refreshKey, setRefreshKey] = useState(0);

  const fetchPosts = useCallback(async () => {
    try {
      const params: Record<string, string> = {};
      if (activeTags.length > 0) params.tags = activeTags.join(',');
      if (sort) params.sort = sort;
      if (ratingFilter) params.rating = ratingFilter;
      if (searchQuery) params.search = searchQuery;
      const data = await getPosts(params);
      setPosts(data);
    } catch {
      // Server might not be running
      setPosts([]);
    }
  }, [activeTags, sort, ratingFilter, searchQuery, refreshKey]);

  useEffect(() => {
    fetchPosts();
  }, [fetchPosts]);

  const handleTagClick = (tag: string) => {
    setActiveTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    setActiveTags([]);
  };

  const handlePostClick = (id: string) => {
    setSelectedPostId(id);
    setPage('post');
  };

  const handleBack = () => {
    setSelectedPostId(null);
    setPage('home');
    // refresh to update scores/comments
    setRefreshKey(k => k + 1);
  };

  const handlePostCreated = () => {
    setRefreshKey(k => k + 1);
  };

  return (
    <div className="min-h-screen bg-gray-950 text-white flex flex-col">
      <Header
        currentPage={page}
        onNavigate={setPage}
        searchQuery={searchQuery}
        onSearch={handleSearch}
      />

      <div className="flex flex-1 overflow-hidden">
        {page === 'home' && (
          <>
            <TagSidebar
              activeTags={activeTags}
              onTagClick={handleTagClick}
              onClearTags={() => setActiveTags([])}
            />
            <div className="flex-1 flex flex-col overflow-y-auto">
              {/* Sort/Filter bar */}
              <div className="bg-gray-900 border-b border-gray-700 px-4 py-2 flex items-center gap-3 text-sm flex-wrap">
                <span className="text-gray-500">Сортировка:</span>
                {[
                  { value: 'date', label: '📅 Новые' },
                  { value: 'score', label: '⭐ Популярные' },
                  { value: 'comments', label: '💬 Обсуждаемые' },
                ].map(s => (
                  <button
                    key={s.value}
                    onClick={() => setSort(s.value)}
                    className={`px-2 py-0.5 rounded transition-colors ${
                      sort === s.value
                        ? 'bg-green-600/20 text-green-400'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}

                <span className="text-gray-700 mx-1">|</span>
                <span className="text-gray-500">Рейтинг:</span>
                {[
                  { value: '', label: 'Все' },
                  { value: 'safe', label: 'Safe' },
                  { value: 'questionable', label: 'Questionable' },
                  { value: 'explicit', label: 'Explicit' },
                ].map(r => (
                  <button
                    key={r.value}
                    onClick={() => setRatingFilter(r.value)}
                    className={`px-2 py-0.5 rounded transition-colors ${
                      ratingFilter === r.value
                        ? 'bg-green-600/20 text-green-400'
                        : 'text-gray-400 hover:text-white'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}

                <span className="ml-auto text-gray-500">
                  {posts.length} пост{posts.length === 1 ? '' : posts.length < 5 ? 'а' : 'ов'}
                </span>
              </div>

              <PostGrid posts={posts} onPostClick={handlePostClick} />
            </div>
          </>
        )}

        {page === 'post' && selectedPostId && (
          <PostDetail
            postId={selectedPostId}
            onBack={handleBack}
            onTagClick={(tag) => {
              setActiveTags([tag]);
              setPage('home');
            }}
          />
        )}

        {page === 'admin' && (
          <AdminPanel onPostCreated={handlePostCreated} />
        )}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
