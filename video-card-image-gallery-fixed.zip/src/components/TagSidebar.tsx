import { useState, useEffect } from 'react';
import { getTags } from '../api';

interface Tag {
  name: string;
  count: number;
}

interface Props {
  activeTags: string[];
  onTagClick: (tag: string) => void;
  onClearTags: () => void;
}

const TAG_CATEGORIES: Record<string, string[]> = {
  'Бренд': ['nvidia', 'amd', 'intel', 'asus', 'msi', 'gigabyte', 'evga', 'zotac', 'sapphire', 'powercolor', 'xfx', 'pny', 'palit', 'galax', 'colorful', 'inno3d'],
  'Серия': ['rtx_4090', 'rtx_4080', 'rtx_4070', 'rtx_4060', 'rtx_3090', 'rtx_3080', 'rtx_3070', 'rtx_3060', 'rx_7900_xtx', 'rx_7900_xt', 'rx_7800_xt', 'rx_7700_xt', 'rx_7600', 'rx_6900_xt', 'arc_a770', 'arc_a750', 'rtx_5090', 'rtx_5080'],
  'Фичи': ['rgb', 'triple_fan', 'dual_fan', 'blower', 'liquid_cooled', 'white', 'black', 'mini', 'founders_edition', 'overclocked', 'silent', 'backplate'],
};

function categorizeTag(tag: string): string {
  for (const [cat, tags] of Object.entries(TAG_CATEGORIES)) {
    if (tags.includes(tag)) return cat;
  }
  return 'Другое';
}

export default function TagSidebar({ activeTags, onTagClick, onClearTags }: Props) {
  const [tags, setTags] = useState<Tag[]>([]);
  const [collapsed, setCollapsed] = useState<Record<string, boolean>>({});

  useEffect(() => {
    getTags().then(setTags).catch(() => {});
  }, []);

  // Group tags
  const grouped: Record<string, Tag[]> = {};
  tags.forEach(tag => {
    const cat = categorizeTag(tag.name);
    if (!grouped[cat]) grouped[cat] = [];
    grouped[cat].push(tag);
  });

  const toggleCategory = (cat: string) => {
    setCollapsed(prev => ({ ...prev, [cat]: !prev[cat] }));
  };

  if (tags.length === 0) {
    return (
      <div className="w-64 shrink-0 bg-gray-900 border-r border-gray-700 p-4 hidden lg:block">
        <h3 className="text-sm font-bold text-gray-400 uppercase mb-3">Теги</h3>
        <p className="text-gray-500 text-sm">Пока нет постов с тегами</p>
      </div>
    );
  }

  return (
    <div className="w-64 shrink-0 bg-gray-900 border-r border-gray-700 p-4 hidden lg:block overflow-y-auto max-h-[calc(100vh-80px)]">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-bold text-gray-400 uppercase">Теги</h3>
        {activeTags.length > 0 && (
          <button onClick={onClearTags} className="text-xs text-red-400 hover:text-red-300">
            Сбросить
          </button>
        )}
      </div>

      {activeTags.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-1">
          {activeTags.map(tag => (
            <button
              key={tag}
              onClick={() => onTagClick(tag)}
              className="text-xs bg-green-600/30 text-green-400 px-2 py-0.5 rounded hover:bg-red-600/30 hover:text-red-400 transition-colors"
            >
              {tag} ×
            </button>
          ))}
        </div>
      )}

      {Object.entries(grouped).map(([category, catTags]) => (
        <div key={category} className="mb-3">
          <button
            onClick={() => toggleCategory(category)}
            className="flex items-center justify-between w-full text-xs font-bold text-gray-500 uppercase mb-1 hover:text-gray-300"
          >
            <span>{category}</span>
            <span>{collapsed[category] ? '▶' : '▼'}</span>
          </button>
          {!collapsed[category] && (
            <div className="space-y-0.5">
              {catTags.sort((a, b) => b.count - a.count).map(tag => (
                <button
                  key={tag.name}
                  onClick={() => onTagClick(tag.name)}
                  className={`flex items-center justify-between w-full text-sm px-2 py-0.5 rounded transition-colors ${
                    activeTags.includes(tag.name)
                      ? 'bg-green-600/20 text-green-400'
                      : 'text-blue-400 hover:bg-gray-800'
                  }`}
                >
                  <span className="truncate">{tag.name.replace(/_/g, ' ')}</span>
                  <span className="text-xs text-gray-500 ml-2">{tag.count}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}
