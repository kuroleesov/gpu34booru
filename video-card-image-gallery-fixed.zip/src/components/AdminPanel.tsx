import { useState, useRef, useCallback } from 'react';
import { createPost } from '../api';
import { useAuth } from '../AuthContext';

interface UploadItem {
  id: string;
  file: File;
  preview: string;
  tags: string[];
  tagInput: string;
  rating: 'safe' | 'questionable' | 'explicit';
  source: string;
  uploading: boolean;
  done: boolean;
  error: string;
}

const TAG_SUGGESTIONS = [
  'nvidia', 'amd', 'intel', 'asus', 'msi', 'gigabyte', 'evga', 'zotac', 'sapphire', 'powercolor',
  'rtx_4090', 'rtx_4080', 'rtx_4070', 'rtx_4060', 'rtx_3090', 'rtx_3080', 'rtx_3070', 'rtx_3060',
  'rx_7900_xtx', 'rx_7900_xt', 'rx_7800_xt', 'rx_7700_xt', 'rx_7600',
  'arc_a770', 'arc_a750', 'rtx_5090', 'rtx_5080',
  'rgb', 'triple_fan', 'dual_fan', 'blower', 'liquid_cooled', 'white', 'black', 'mini',
  'founders_edition', 'overclocked', 'silent', 'backplate', 'pcie_5', 'gddr6x', 'gddr6',
  'ray_tracing', 'dlss', 'fsr', 'benchmark', 'teardown', 'unboxing', 'comparison',
];

let nextId = 0;

export default function AdminPanel({ onPostCreated }: { onPostCreated: () => void }) {
  const { isAdmin } = useAuth();
  const [items, setItems] = useState<UploadItem[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addFiles = useCallback((files: FileList | File[]) => {
    const newItems: UploadItem[] = Array.from(files)
      .filter(f => f.type.startsWith('image/'))
      .map(file => ({
        id: 'upload_' + (nextId++),
        file,
        preview: URL.createObjectURL(file),
        tags: [],
        tagInput: '',
        rating: 'safe' as const,
        source: '',
        uploading: false,
        done: false,
        error: '',
      }));
    setItems(prev => [...prev, ...newItems]);
  }, []);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files.length) addFiles(e.dataTransfer.files);
  };

  const removeItem = (id: string) => {
    setItems(prev => {
      const item = prev.find(i => i.id === id);
      if (item) URL.revokeObjectURL(item.preview);
      return prev.filter(i => i.id !== id);
    });
  };

  const updateItem = (id: string, updates: Partial<UploadItem>) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, ...updates } : i));
  };

  const addTag = (itemId: string, tag: string) => {
    const clean = tag.trim().toLowerCase().replace(/\s+/g, '_');
    if (!clean) return;
    setItems(prev => prev.map(i => {
      if (i.id !== itemId) return i;
      if (i.tags.includes(clean)) return { ...i, tagInput: '' };
      return { ...i, tags: [...i.tags, clean], tagInput: '' };
    }));
  };

  const removeTag = (itemId: string, tag: string) => {
    setItems(prev => prev.map(i => {
      if (i.id !== itemId) return i;
      return { ...i, tags: i.tags.filter(t => t !== tag) };
    }));
  };

  const handleTagKeyDown = (itemId: string, e: React.KeyboardEvent<HTMLInputElement>) => {
    const item = items.find(i => i.id === itemId);
    if (!item) return;
    if (e.key === 'Enter' || e.key === ',' || e.key === ' ') {
      e.preventDefault();
      addTag(itemId, item.tagInput);
    } else if (e.key === 'Backspace' && !item.tagInput && item.tags.length > 0) {
      removeTag(itemId, item.tags[item.tags.length - 1]);
    }
  };

  const uploadItem = async (item: UploadItem) => {
    updateItem(item.id, { uploading: true, error: '' });
    try {
      const formData = new FormData();
      formData.append('image', item.file);
      formData.append('tags', item.tags.join(','));
      formData.append('rating', item.rating);
      formData.append('source', item.source);
      await createPost(formData);
      updateItem(item.id, { uploading: false, done: true });
      onPostCreated();
    } catch (err: unknown) {
      updateItem(item.id, {
        uploading: false,
        error: err instanceof Error ? err.message : 'Upload failed',
      });
    }
  };

  const uploadAll = async () => {
    const pending = items.filter(i => !i.done && !i.uploading);
    for (const item of pending) {
      await uploadItem(item);
    }
  };

  const getFilteredSuggestions = (input: string) => {
    if (!input) return [];
    return TAG_SUGGESTIONS.filter(t =>
      t.includes(input.toLowerCase()) &&
      !items.some(i => i.tags.includes(t))
    ).slice(0, 8);
  };

  if (!isAdmin) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="text-center">
          <div className="text-6xl mb-4">🔒</div>
          <h2 className="text-xl font-bold text-red-400 mb-2">Доступ запрещён</h2>
          <p className="text-gray-500">Только администратор может загружать изображения</p>
        </div>
      </div>
    );
  }

  const pendingCount = items.filter(i => !i.done).length;
  const doneCount = items.filter(i => i.done).length;

  return (
    <div className="flex-1 overflow-y-auto p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-green-400">📤 Админ-панель</h1>
            <p className="text-gray-500 text-sm mt-1">Загрузите изображения видеокарт, добавьте теги и опубликуйте</p>
          </div>
          {items.length > 0 && (
            <div className="text-sm text-gray-400">
              {doneCount}/{items.length} загружено
            </div>
          )}
        </div>

        {/* Drop zone */}
        <div
          onDragOver={e => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
          className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-colors mb-6 ${
            dragOver
              ? 'border-green-500 bg-green-500/10'
              : 'border-gray-600 hover:border-gray-500 bg-gray-800/50'
          }`}
        >
          <div className="text-4xl mb-3">{dragOver ? '📥' : '🖼️'}</div>
          <p className="text-gray-300 font-medium">
            {dragOver ? 'Отпустите файлы здесь' : 'Перетащите изображения сюда'}
          </p>
          <p className="text-gray-500 text-sm mt-1">или нажмите для выбора файлов</p>
          <p className="text-gray-600 text-xs mt-2">JPG, PNG, GIF, WebP • до 50MB</p>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept="image/*"
            onChange={e => e.target.files && addFiles(e.target.files)}
            className="hidden"
          />
        </div>

        {/* Upload items */}
        {items.length > 0 && (
          <>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-gray-300">
                Файлы для загрузки ({pendingCount} в очереди)
              </h2>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    items.forEach(i => URL.revokeObjectURL(i.preview));
                    setItems([]);
                  }}
                  className="text-sm px-3 py-1.5 bg-gray-700 text-gray-300 hover:bg-red-600 hover:text-white rounded transition-colors"
                >
                  Очистить всё
                </button>
                {pendingCount > 0 && (
                  <button
                    onClick={uploadAll}
                    className="text-sm px-4 py-1.5 bg-green-600 hover:bg-green-700 text-white font-bold rounded transition-colors"
                  >
                    🚀 Загрузить всё ({pendingCount})
                  </button>
                )}
              </div>
            </div>

            <div className="space-y-4">
              {items.map(item => (
                <div
                  key={item.id}
                  className={`bg-gray-800 border rounded-lg overflow-hidden ${
                    item.done ? 'border-green-600' : item.error ? 'border-red-600' : 'border-gray-700'
                  }`}
                >
                  <div className="flex gap-4 p-4">
                    {/* Preview */}
                    <div className="w-32 h-32 shrink-0 bg-gray-900 rounded overflow-hidden">
                      <img
                        src={item.preview}
                        alt="preview"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Form */}
                    <div className="flex-1 min-w-0 space-y-3">
                      {/* File name */}
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-300 truncate font-medium">
                          {item.file.name}
                          <span className="text-gray-500 ml-2">
                            ({(item.file.size / 1024 / 1024).toFixed(1)} MB)
                          </span>
                        </span>
                        {!item.uploading && (
                          <button
                            onClick={() => removeItem(item.id)}
                            className="text-gray-500 hover:text-red-400 text-lg ml-2"
                          >
                            ×
                          </button>
                        )}
                      </div>

                      {item.done ? (
                        <div className="text-green-400 font-bold text-sm">✅ Загружено успешно!</div>
                      ) : item.uploading ? (
                        <div className="text-yellow-400 text-sm">⏳ Загрузка...</div>
                      ) : (
                        <>
                          {/* Tags */}
                          <div>
                            <label className="text-xs text-gray-500 mb-1 block">Теги</label>
                            <div className="flex flex-wrap gap-1 bg-gray-900 border border-gray-600 rounded p-2 min-h-[36px]">
                              {item.tags.map(tag => (
                                <span
                                  key={tag}
                                  className="flex items-center gap-1 text-xs bg-green-600/20 text-green-400 px-2 py-0.5 rounded"
                                >
                                  {tag}
                                  <button
                                    onClick={() => removeTag(item.id, tag)}
                                    className="hover:text-red-400"
                                  >
                                    ×
                                  </button>
                                </span>
                              ))}
                              <div className="relative flex-1 min-w-[120px]">
                                <input
                                  type="text"
                                  value={item.tagInput}
                                  onChange={e => updateItem(item.id, { tagInput: e.target.value })}
                                  onKeyDown={e => handleTagKeyDown(item.id, e)}
                                  placeholder={item.tags.length ? '' : 'nvidia, rtx_4090, rgb...'}
                                  className="w-full bg-transparent text-sm text-white placeholder-gray-500 outline-none"
                                />
                                {/* Suggestions dropdown */}
                                {item.tagInput && (
                                  <div className="absolute top-full left-0 mt-1 bg-gray-900 border border-gray-600 rounded shadow-lg z-10 max-h-40 overflow-y-auto">
                                    {getFilteredSuggestions(item.tagInput).map(sug => (
                                      <button
                                        key={sug}
                                        onClick={() => addTag(item.id, sug)}
                                        className="block w-full text-left text-sm px-3 py-1.5 text-blue-400 hover:bg-gray-800 whitespace-nowrap"
                                      >
                                        {sug}
                                      </button>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Rating + Source */}
                          <div className="flex gap-3">
                            <div>
                              <label className="text-xs text-gray-500 mb-1 block">Рейтинг</label>
                              <div className="flex gap-1">
                                {(['safe', 'questionable', 'explicit'] as const).map(r => (
                                  <button
                                    key={r}
                                    onClick={() => updateItem(item.id, { rating: r })}
                                    className={`text-xs px-2 py-1 rounded transition-colors ${
                                      item.rating === r
                                        ? r === 'safe' ? 'bg-green-600 text-white'
                                          : r === 'questionable' ? 'bg-yellow-600 text-white'
                                          : 'bg-red-600 text-white'
                                        : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
                                    }`}
                                  >
                                    {r === 'safe' ? 'Safe' : r === 'questionable' ? 'Questionable' : 'Explicit'}
                                  </button>
                                ))}
                              </div>
                            </div>
                            <div className="flex-1">
                              <label className="text-xs text-gray-500 mb-1 block">Источник (URL)</label>
                              <input
                                type="text"
                                value={item.source}
                                onChange={e => updateItem(item.id, { source: e.target.value })}
                                placeholder="https://..."
                                className="w-full bg-gray-900 border border-gray-600 rounded px-2 py-1 text-sm text-white placeholder-gray-500 focus:border-green-500 focus:outline-none"
                              />
                            </div>
                          </div>

                          {/* Upload button */}
                          <button
                            onClick={() => uploadItem(item)}
                            className="bg-green-600 hover:bg-green-700 text-white text-sm px-4 py-1.5 rounded transition-colors"
                          >
                            📤 Загрузить
                          </button>
                        </>
                      )}

                      {item.error && (
                        <div className="text-red-400 text-sm">❌ {item.error}</div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
