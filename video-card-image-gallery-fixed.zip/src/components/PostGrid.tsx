import { getImageUrl } from '../api';

interface Post {
  id: string;
  filename: string;
  tags: string[];
  rating: string;
  score: number;
  commentCount: number;
  uploader: string;
  createdAt: string;
}

interface Props {
  posts: Post[];
  onPostClick: (id: string) => void;
}

function ratingBadge(rating: string) {
  switch (rating) {
    case 'safe': return { label: 'S', cls: 'bg-green-600' };
    case 'questionable': return { label: 'Q', cls: 'bg-yellow-600' };
    case 'explicit': return { label: 'E', cls: 'bg-red-600' };
    default: return { label: 'S', cls: 'bg-green-600' };
  }
}

export default function PostGrid({ posts, onPostClick }: Props) {
  if (posts.length === 0) {
    return (
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="text-center">
          <div className="text-6xl mb-4">🖥️</div>
          <h2 className="text-xl font-bold text-gray-400 mb-2">Пока нет постов</h2>
          <p className="text-gray-500 text-sm">
            Админ может загрузить изображения через панель загрузки
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 p-4">
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
        {posts.map(post => {
          const badge = ratingBadge(post.rating);
          return (
            <div
              key={post.id}
              onClick={() => onPostClick(post.id)}
              className="group relative bg-gray-800 border border-gray-700 rounded overflow-hidden cursor-pointer hover:border-green-500 transition-colors"
            >
              <div className="aspect-square bg-gray-900 overflow-hidden">
                <img
                  src={getImageUrl(post.filename)}
                  alt={post.tags.join(', ')}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                  loading="lazy"
                />
              </div>

              {/* Rating badge */}
              <div className={`absolute top-1 left-1 ${badge.cls} text-white text-xs font-bold w-5 h-5 flex items-center justify-center rounded`}>
                {badge.label}
              </div>

              {/* Score overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-2 pt-6">
                <div className="flex items-center justify-between text-xs">
                  <span className={`font-bold ${post.score > 0 ? 'text-green-400' : post.score < 0 ? 'text-red-400' : 'text-gray-400'}`}>
                    ▲ {post.score}
                  </span>
                  <span className="text-gray-400">
                    💬 {post.commentCount}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
