import { useState } from 'react';
import { useAuth } from '../AuthContext';
import AuthModal from './AuthModal';

interface Props {
  currentPage: string;
  onNavigate: (page: string) => void;
  searchQuery: string;
  onSearch: (q: string) => void;
}

export default function Header({ currentPage, onNavigate, searchQuery, onSearch }: Props) {
  const { user, isAdmin, isLoggedIn, logout } = useAuth();
  const [showAuth, setShowAuth] = useState(false);
  const [localSearch, setLocalSearch] = useState(searchQuery);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(localSearch);
    onNavigate('home');
  };

  return (
    <>
      <header className="bg-gray-900 border-b border-gray-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4">
          {/* Top bar */}
          <div className="flex items-center justify-between h-14">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <span className="text-2xl">🎮</span>
              <span className="text-xl font-bold">
                <span className="text-green-400">GPU</span>
                <span className="text-gray-400">34</span>
              </span>
            </button>

            {/* Search */}
            <form onSubmit={handleSearch} className="flex-1 max-w-xl mx-4">
              <div className="relative">
                <input
                  type="text"
                  value={localSearch}
                  onChange={e => setLocalSearch(e.target.value)}
                  placeholder="Поиск по тегам... (nvidia, rtx_4090, rgb)"
                  className="w-full bg-gray-800 border border-gray-600 rounded px-3 py-1.5 text-sm text-white placeholder-gray-500 focus:border-green-500 focus:outline-none"
                />
                <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-green-400">
                  🔍
                </button>
              </div>
            </form>

            {/* User area */}
            <div className="flex items-center gap-3">
              {isLoggedIn ? (
                <>
                  <span className="text-sm text-gray-300">
                    {isAdmin && <span className="text-yellow-400 mr-1">👑</span>}
                    {user?.username}
                  </span>
                  {isAdmin && (
                    <button
                      onClick={() => onNavigate('admin')}
                      className={`text-sm px-3 py-1 rounded transition-colors ${
                        currentPage === 'admin'
                          ? 'bg-green-600 text-white'
                          : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                      }`}
                    >
                      📤 Загрузить
                    </button>
                  )}
                  <button
                    onClick={logout}
                    className="text-sm px-3 py-1 bg-gray-700 text-gray-300 hover:bg-red-600 hover:text-white rounded transition-colors"
                  >
                    Выйти
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setShowAuth(true)}
                  className="text-sm px-3 py-1 bg-green-600 hover:bg-green-700 text-white rounded transition-colors"
                >
                  🔑 Войти
                </button>
              )}
            </div>
          </div>

          {/* Nav */}
          <div className="flex items-center gap-1 pb-2 text-sm overflow-x-auto">
            <button
              onClick={() => onNavigate('home')}
              className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
                currentPage === 'home' ? 'bg-green-600/20 text-green-400' : 'text-gray-400 hover:text-white'
              }`}
            >
              📋 Посты
            </button>
            {isAdmin && (
              <button
                onClick={() => onNavigate('admin')}
                className={`px-3 py-1 rounded transition-colors whitespace-nowrap ${
                  currentPage === 'admin' ? 'bg-green-600/20 text-green-400' : 'text-gray-400 hover:text-white'
                }`}
              >
                ⚙️ Админ-панель
              </button>
            )}
          </div>
        </div>
      </header>

      {showAuth && <AuthModal onClose={() => setShowAuth(false)} />}
    </>
  );
}
