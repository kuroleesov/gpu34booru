import { useState, useEffect } from 'react';
import { getPost, votePost, addComment, deleteComment, deletePost, getImageUrl } from '../api';
import { useAuth } from '../AuthContext';

interface Comment {
  id: string;
  text: string;
  author: string;
  authorId: string;
  createdAt: string;
}

interface PostData {
  id: string;
  filename: string;
  originalName: string;
  tags: string[];
  rating: string;
  source: string;
  score: number;
  votes: Record<string, string>;
  comments: Comment[];
  uploader: string;
  uploaderId: string;
  createdAt: string;
  fileSize: number;
}

interface Props {
  postId: string;
  onBack: () => void;
  onTagClick: (tag: string) => void;
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
}

function timeAgo(dateStr: string): string {
  const seconds = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (seconds < 60) return 'только что';
  if (seconds < 3600) return Math.floor(seconds / 60) + ' мин. назад';
  if (seconds < 86400) return Math.floor(seconds / 3600) + ' ч. назад';
  return Math.floor(seconds / 86400) + ' дн. назад';
}

export default function PostDetail({ postId, onBack, onTagClick }: Props) {
  const { user, isAdmin, isLoggedIn } = useAuth();
  const [post, setPost] = useState<PostData | null>(null);
  const [loading, setLoading] = useState(true);
  const [commentText, setCommentText] = useState('');
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    setLoading(true);
    getPost(postId)
      .then(setPost)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [postId]);

  const handleVote = async (direction: 'up' | 'down') => {
    if (!isLoggedIn || !post) return;
    try {
      const result = await votePost(post.id, direction);
      setPost(prev => prev ? { ...prev, score: result.score } : prev);
    } catch { /* ignore */ }
  };

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentText.trim() || !post) return;
    setSubmitting(true);
    try {
      const comment = await addComment(post.id, commentText);
      setPost(prev => prev ? { ...prev, comments: [...prev.comments, comment] } : prev);
      setCommentText('');
    } catch { /* ignore */ }
    setSubmitting(false);
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!post) return;
    try {
      await deleteComment(post.id, commentId);
      setPost(prev => prev ? { ...prev, comments: prev.comments.filter(c => c.id !== commentId) } : prev);
    } catch { /* ignore */ }
  };

  const handleDeletePost = async () => {
    if (!post || !confirm('Удалить этот пост навсегда?')) return;
    try {
      await deletePost(post.id);
      onBack();
    } catch { /* ignore */ }
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-green-400 text-xl">⏳ Загрузка...</div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <div className="text-4xl mb-2">😢</div>
          <p className="text-gray-400">Пост не найден</p>
          <button onClick={onBack} className="mt-4 text-green-400 hover:underline">← Назад</button>
        </div>
      </div>
    );
  }

  const userVote = user ? post.votes?.[user.id] : null;

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-6xl mx-auto p-4">
        {/* Back button */}
        <button onClick={onBack} className="text-green-400 hover:underline mb-4 text-sm">
          ← Вернуться к постам
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Image */}
          <div className="lg:col-span-2">
            <div className="bg-gray-900 border border-gray-700 rounded overflow-hidden">
              <img
                src={getImageUrl(post.filename)}
                alt={post.tags.join(', ')}
                className="w-full h-auto"
              />
            </div>
          </div>

          {/* Info sidebar */}
          <div className="space-y-4">
            {/* Votes */}
            <div className="bg-gray-800 border border-gray-700 rounded p-4">
              <div className="flex items-center justify-center gap-4">
                <button
                  onClick={() => handleVote('up')}
                  disabled={!isLoggedIn}
                  className={`text-2xl transition-transform hover:scale-110 ${
                    userVote === 'up' ? 'text-green-400' : 'text-gray-500'
                  } ${!isLoggedIn ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'}`}
                  title={isLoggedIn ? 'Нравится' : 'Войдите чтобы голосовать'}
                >
                  👍
                </button>
                <span className={`text-2xl font-bold ${
                  post.score > 0 ? 'text-green-400' : post.score < 0 ? 'text-red-400' : 'text-gray-400'
                }`}>
                  {post.score}
                </span>
                <button
                  onClick={() => handleVote('down')}
                  disabled={!isLoggedIn}
                  className={`text-2xl transition-transform hover:scale-110 ${
                    userVote === 'down' ? 'text-red-400' : 'text-gray-500'
                  } ${!isLoggedIn ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer'}`}
                  title={isLoggedIn ? 'Не нравится' : 'Войдите чтобы голосовать'}
                >
                  👎
                </button>
              </div>
            </div>

            {/* Info */}
            <div className="bg-gray-800 border border-gray-700 rounded p-4 space-y-2 text-sm">
              <h3 className="font-bold text-gray-300 mb-2">📋 Информация</h3>
              <div className="flex justify-between">
                <span className="text-gray-500">Загрузил:</span>
                <span className="text-green-400">{post.uploader}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Дата:</span>
                <span className="text-gray-300">{timeAgo(post.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Размер файла:</span>
                <span className="text-gray-300">{formatSize(post.fileSize)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Рейтинг:</span>
                <span className={`font-bold ${
                  post.rating === 'safe' ? 'text-green-400' :
                  post.rating === 'questionable' ? 'text-yellow-400' : 'text-red-400'
                }`}>
                  {post.rating === 'safe' ? 'Safe' : post.rating === 'questionable' ? 'Questionable' : 'Explicit'}
                </span>
              </div>
              {post.source && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Источник:</span>
                  <a href={post.source} target="_blank" rel="noopener" className="text-blue-400 hover:underline truncate ml-2">
                    {post.source}
                  </a>
                </div>
              )}
            </div>

            {/* Tags */}
            <div className="bg-gray-800 border border-gray-700 rounded p-4">
              <h3 className="font-bold text-gray-300 mb-2 text-sm">🏷️ Теги</h3>
              <div className="flex flex-wrap gap-1">
                {post.tags.map(tag => (
                  <button
                    key={tag}
                    onClick={() => { onTagClick(tag); onBack(); }}
                    className="text-xs bg-gray-700 text-blue-400 hover:bg-gray-600 px-2 py-1 rounded transition-colors"
                  >
                    {tag.replace(/_/g, ' ')}
                  </button>
                ))}
                {post.tags.length === 0 && (
                  <span className="text-gray-500 text-xs">Нет тегов</span>
                )}
              </div>
            </div>

            {/* Admin actions */}
            {isAdmin && (
              <div className="bg-gray-800 border border-red-900 rounded p-4">
                <h3 className="font-bold text-red-400 mb-2 text-sm">🔧 Админ</h3>
                <button
                  onClick={handleDeletePost}
                  className="w-full bg-red-600 hover:bg-red-700 text-white text-sm py-2 rounded transition-colors"
                >
                  🗑️ Удалить пост
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Comments */}
        <div className="mt-6 bg-gray-800 border border-gray-700 rounded p-4">
          <h3 className="font-bold text-gray-300 mb-4">💬 Комментарии ({post.comments.length})</h3>

          {isLoggedIn ? (
            <form onSubmit={handleComment} className="mb-4">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={commentText}
                  onChange={e => setCommentText(e.target.value)}
                  placeholder="Написать комментарий..."
                  className="flex-1 bg-gray-900 border border-gray-600 rounded px-3 py-2 text-sm text-white placeholder-gray-500 focus:border-green-500 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={submitting || !commentText.trim()}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white text-sm px-4 py-2 rounded transition-colors"
                >
                  {submitting ? '...' : 'Отправить'}
                </button>
              </div>
            </form>
          ) : (
            <p className="text-gray-500 text-sm mb-4">
              🔑 Войдите чтобы оставить комментарий
            </p>
          )}

          <div className="space-y-3">
            {post.comments.length === 0 && (
              <p className="text-gray-500 text-sm text-center py-4">Пока нет комментариев</p>
            )}
            {post.comments.map(comment => (
              <div key={comment.id} className="bg-gray-900 rounded p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-bold text-green-400">{comment.author}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">{timeAgo(comment.createdAt)}</span>
                    {(isAdmin || user?.id === comment.authorId) && (
                      <button
                        onClick={() => handleDeleteComment(comment.id)}
                        className="text-xs text-red-400 hover:text-red-300"
                      >
                        🗑️
                      </button>
                    )}
                  </div>
                </div>
                <p className="text-sm text-gray-300">{comment.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
