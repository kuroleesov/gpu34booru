import express from 'express';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import cors from 'cors';
import { v4 as uuidv4 } from 'uuid';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;
const JWT_SECRET = process.env.JWT_SECRET || 'gpu34-super-secret-key-change-me';

// --- Paths ---
const DB_PATH = path.join(__dirname, 'db.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');
const THUMBS_DIR = path.join(__dirname, 'uploads', 'thumbs');

// Create directories
if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true });
if (!fs.existsSync(THUMBS_DIR)) fs.mkdirSync(THUMBS_DIR, { recursive: true });

// --- DB helpers ---
function readDB() {
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    return JSON.parse(raw);
  } catch {
    return { users: [], posts: [] };
  }
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

// --- Multer config ---
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOADS_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, uuidv4() + ext);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    const allowed = /\.(jpg|jpeg|png|gif|webp|bmp)$/i;
    if (allowed.test(path.extname(file.originalname))) {
      cb(null, true);
    } else {
      cb(new Error('Only image files allowed'));
    }
  }
});

// --- Middleware ---
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(UPLOADS_DIR));

// Auth middleware
function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ error: 'No token' });
  const token = header.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch {
    return res.status(401).json({ error: 'Invalid token' });
  }
}

function adminMiddleware(req, res, next) {
  if (!req.user || !req.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

// ==================== AUTH ROUTES ====================

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
    if (username.length < 3) return res.status(400).json({ error: 'Username must be at least 3 characters' });
    if (password.length < 4) return res.status(400).json({ error: 'Password must be at least 4 characters' });

    const db = readDB();
    const exists = db.users.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (exists) return res.status(400).json({ error: 'Username already taken' });

    const hash = await bcrypt.hash(password, 10);
    const isAdmin = db.users.length === 0; // First user = admin

    const user = {
      id: uuidv4(),
      username,
      password: hash,
      isAdmin,
      createdAt: new Date().toISOString()
    };

    db.users.push(user);
    writeDB(db);

    const token = jwt.sign({ id: user.id, username: user.username, isAdmin: user.isAdmin }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      token,
      user: { id: user.id, username: user.username, isAdmin: user.isAdmin }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) return res.status(400).json({ error: 'Username and password required' });

    const db = readDB();
    const user = db.users.find(u => u.username.toLowerCase() === username.toLowerCase());
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign({ id: user.id, username: user.username, isAdmin: user.isAdmin }, JWT_SECRET, { expiresIn: '30d' });

    res.json({
      token,
      user: { id: user.id, username: user.username, isAdmin: user.isAdmin }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get current user
app.get('/api/auth/me', authMiddleware, (req, res) => {
  res.json({ user: req.user });
});

// ==================== POSTS ROUTES ====================

// Get all posts (public)
app.get('/api/posts', (req, res) => {
  const db = readDB();
  const { tags, sort, rating, search } = req.query;

  let posts = [...db.posts];

  // Filter by tags
  if (tags) {
    const tagList = tags.split(',').map(t => t.trim().toLowerCase());
    posts = posts.filter(p => tagList.every(t => p.tags.map(pt => pt.toLowerCase()).includes(t)));
  }

  // Filter by rating
  if (rating) {
    posts = posts.filter(p => p.rating === rating);
  }

  // Search
  if (search) {
    const q = search.toLowerCase();
    posts = posts.filter(p =>
      p.tags.some(t => t.toLowerCase().includes(q)) ||
      (p.source && p.source.toLowerCase().includes(q))
    );
  }

  // Sort
  switch (sort) {
    case 'score':
      posts.sort((a, b) => b.score - a.score);
      break;
    case 'comments':
      posts.sort((a, b) => (b.comments?.length || 0) - (a.comments?.length || 0));
      break;
    case 'date':
    default:
      posts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  // Return without heavy data
  const result = posts.map(p => ({
    id: p.id,
    filename: p.filename,
    tags: p.tags,
    rating: p.rating,
    score: p.score,
    commentCount: p.comments?.length || 0,
    uploader: p.uploader,
    createdAt: p.createdAt,
    width: p.width,
    height: p.height,
    fileSize: p.fileSize
  }));

  res.json(result);
});

// Get single post (public)
app.get('/api/posts/:id', (req, res) => {
  const db = readDB();
  const post = db.posts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });
  res.json(post);
});

// Create post (admin only)
app.post('/api/posts', authMiddleware, adminMiddleware, upload.single('image'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'Image required' });

    const { tags, rating, source } = req.body;
    const tagList = tags ? tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean) : [];

    const post = {
      id: uuidv4(),
      filename: req.file.filename,
      originalName: req.file.originalname,
      tags: tagList,
      rating: rating || 'safe',
      source: source || '',
      score: 0,
      votes: {},
      comments: [],
      uploader: req.user.username,
      uploaderId: req.user.id,
      createdAt: new Date().toISOString(),
      fileSize: req.file.size,
      width: 0,
      height: 0
    };

    const db = readDB();
    db.posts.push(post);
    writeDB(db);

    res.json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update post tags/rating (admin only)
app.put('/api/posts/:id', authMiddleware, adminMiddleware, (req, res) => {
  const db = readDB();
  const idx = db.posts.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Post not found' });

  const { tags, rating, source } = req.body;
  if (tags !== undefined) {
    db.posts[idx].tags = Array.isArray(tags) ? tags : tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean);
  }
  if (rating) db.posts[idx].rating = rating;
  if (source !== undefined) db.posts[idx].source = source;

  writeDB(db);
  res.json(db.posts[idx]);
});

// Delete post (admin only)
app.delete('/api/posts/:id', authMiddleware, adminMiddleware, (req, res) => {
  const db = readDB();
  const idx = db.posts.findIndex(p => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Post not found' });

  const post = db.posts[idx];

  // Delete file
  const filePath = path.join(UPLOADS_DIR, post.filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

  db.posts.splice(idx, 1);
  writeDB(db);
  res.json({ success: true });
});

// Vote on post (authenticated)
app.post('/api/posts/:id/vote', authMiddleware, (req, res) => {
  const { direction } = req.body; // 'up' or 'down'
  const db = readDB();
  const post = db.posts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  if (!post.votes) post.votes = {};
  const prev = post.votes[req.user.id];

  if (prev === direction) {
    // Remove vote
    delete post.votes[req.user.id];
  } else {
    post.votes[req.user.id] = direction;
  }

  // Recalculate score
  post.score = Object.values(post.votes).reduce((sum, v) => sum + (v === 'up' ? 1 : -1), 0);

  writeDB(db);
  res.json({ score: post.score, userVote: post.votes[req.user.id] || null });
});

// Add comment (authenticated)
app.post('/api/posts/:id/comments', authMiddleware, (req, res) => {
  const { text } = req.body;
  if (!text || !text.trim()) return res.status(400).json({ error: 'Comment text required' });

  const db = readDB();
  const post = db.posts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  if (!post.comments) post.comments = [];

  const comment = {
    id: uuidv4(),
    text: text.trim(),
    author: req.user.username,
    authorId: req.user.id,
    createdAt: new Date().toISOString()
  };

  post.comments.push(comment);
  writeDB(db);
  res.json(comment);
});

// Delete comment (admin or author)
app.delete('/api/posts/:postId/comments/:commentId', authMiddleware, (req, res) => {
  const db = readDB();
  const post = db.posts.find(p => p.id === req.params.postId);
  if (!post) return res.status(404).json({ error: 'Post not found' });

  const cIdx = post.comments.findIndex(c => c.id === req.params.commentId);
  if (cIdx === -1) return res.status(404).json({ error: 'Comment not found' });

  const comment = post.comments[cIdx];
  if (comment.authorId !== req.user.id && !req.user.isAdmin) {
    return res.status(403).json({ error: 'Not allowed' });
  }

  post.comments.splice(cIdx, 1);
  writeDB(db);
  res.json({ success: true });
});

// Get all tags (public)
app.get('/api/tags', (req, res) => {
  const db = readDB();
  const tagMap = {};
  db.posts.forEach(p => {
    p.tags.forEach(t => {
      tagMap[t] = (tagMap[t] || 0) + 1;
    });
  });
  const tags = Object.entries(tagMap)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);
  res.json(tags);
});

// Get stats (public)
app.get('/api/stats', (req, res) => {
  const db = readDB();
  res.json({
    totalPosts: db.posts.length,
    totalUsers: db.users.length,
    totalComments: db.posts.reduce((sum, p) => sum + (p.comments?.length || 0), 0)
  });
});

// Serve frontend in production
const distPath = path.join(__dirname, '..', 'dist');
if (fs.existsSync(distPath)) {
  app.use(express.static(distPath));
  app.get('/*splat', (req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.listen(PORT, () => {
  console.log(`🚀 GPU34 server running at http://localhost:${PORT}`);
  const db = readDB();
  console.log(`📊 ${db.posts.length} posts, ${db.users.length} users`);
  if (db.users.length === 0) {
    console.log(`⚠️  No users yet. First registered user will be admin!`);
  }
});
